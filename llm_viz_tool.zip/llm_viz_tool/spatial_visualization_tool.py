# spatial_visualization_tool.py
import os
import json
import base64
import threading
from typing import Literal, Optional
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser
from spatial_utils import SPATIAL_PLOT_GUIDES, get_spatial_plot_class
from spatial_figure_generation import main as spatial_main
import logging
from langchain.schema import SystemMessage, HumanMessage

# Get BASE_URL from environment with better error handling
try:
    BASE_URL = os.environ.get("BASE_URL", "http://localhost:8000")
except KeyError:
    raise ValueError("BASE_URL environment variable is not set. Please set it in your .env file.")

# Set paths for spatial data
SPATIAL_DATA_FILE = "/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/sctriangulate.h5ad"
SPATIAL_METADATA_FILE = "/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/metadata_spatial_structured.json"
SPATIAL_OUTPUT_DIR = "/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/results"

# -----------------------------
# LLM Models
# -----------------------------
spatial_visualization_llm_base = ChatOpenAI(model="gpt-4o-mini-2024-07-18")
spatial_visualization_llm_advanced = ChatOpenAI(model="gpt-4o-mini-2024-07-18")

# Suppress logging
logging.getLogger('matplotlib.font_manager').setLevel(logging.ERROR)

# -----------------------------
# Workflow 1: Plot Selection (No dataset selection for spatial - only one dataset)
# -----------------------------

class SpatialWorkflow1Model(BaseModel):
    plot_type: Literal[
        "plot_spatial", "plot_umap", "plot_gene_spatial", 
        "rank_cross_platform_gene_correlation", "plot_cross_platform_gene_correlation",
        "rank_marker_specificity", "find_top_markers_for_celltype",
        "scTriangulate_summarize_celltype_stability", "plot_ARI_dotplot",
        "plot_marker_expression_dotplot", "plot_cluster_composition_groupedbar",
        "compare_annotations_via_heatmap", "visualize_matched_pairs_scatter"
    ]
    reason: str

spatial_workflow1_parser = PydanticOutputParser(pydantic_object=SpatialWorkflow1Model)

SPATIAL_WORKFLOW1_PROMPT_TEMPLATE = """\
DEEPLY ANALYZE THE USER QUERY AND BASED ON THE AVAILABLE SPATIAL DATASET METADATA, PERFORM THE FOLLOWING TASKS:

1. **Plot Type Selection:**
   - Determine the most suitable spatial plot type for visualizing the data in the context of the user's query.
   - Use the following spatial plot type guidelines to assist your selection:

    1. **plot_spatial**
       - Shows spatial distribution of cell types or annotations on tissue coordinates.
       - Use for visualizing how different cell types are distributed across tissue space.

    2. **plot_umap**
       - Displays cells in UMAP embedding colored by annotations.
       - Best for overview of cell clusters or batch effects across platforms.

    3. **plot_gene_spatial**
       - Shows spatial expression patterns of specific genes.
       - Use when user asks about specific gene expression in spatial context.

    4. **rank_cross_platform_gene_correlation**
       - Identifies genes with highest correlation between Visium and Xenium platforms.
       - Use for cross-platform validation or finding conserved spatial patterns.

    5. **plot_cross_platform_gene_correlation**
       - Visualizes correlation curves for specific genes across platforms.
       - Use to show how well genes correlate between spatial technologies.

    6. **rank_marker_specificity**
       - Ranks genes by their specificity to cell types in spatial context.
       - Use for identifying spatial markers for cell types.

    7. **find_top_markers_for_celltype**
       - Finds top marker genes for specific cell types.
       - Use when user asks about markers for particular cell types.

    8. **scTriangulate_summarize_celltype_stability**
       - Analyzes stability of cell type annotations across different methods.
       - Use for annotation quality assessment.

    9. **plot_ARI_dotplot**
       - Shows adjusted rand index between different annotations.
       - Use for comparing annotation methods.

    10. **plot_marker_expression_dotplot**
        - Dotplot showing marker gene expression across cell types.
        - Use for marker gene visualization across cell types.

    11. **plot_cluster_composition_groupedbar**
        - Bar plot showing composition of clusters or annotations.
        - Use for cell type proportion analysis.

    12. **compare_annotations_via_heatmap**
        - Heatmap comparing different annotation methods.
        - Use for annotation comparison visualization.

    13. **visualize_matched_pairs_scatter**
        - Scatter plot for matched pairs analysis.
        - Use for paired sample comparisons.

Dataset Metadata:
{dataset_metadata}

User Query:
{user_query}

Your output should be a single JSON object adhering to this schema:
{format_instructions}
"""

spatial_workflow1_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", SPATIAL_WORKFLOW1_PROMPT_TEMPLATE),
        ("human", "{user_query}")
    ]
).partial(format_instructions=spatial_workflow1_parser.get_format_instructions())

def get_spatial_metadata() -> str:
    """Load spatial metadata from JSON file"""
    with open(SPATIAL_METADATA_FILE, 'r') as f:
        metadata = json.load(f)
    return json.dumps(metadata, indent=4)

async def run_spatial_workflow1(user_query: str) -> SpatialWorkflow1Model:
    dataset_metadata_str = get_spatial_metadata()
    model = spatial_visualization_llm_base
    chain = spatial_workflow1_prompt | model | spatial_workflow1_parser
    
    # Format the prompt
    prompt_input = {
        "user_query": user_query,
        "dataset_metadata": dataset_metadata_str
    }
    
    # Invoke the chain asynchronously and get the response
    result = await chain.ainvoke(prompt_input)
    
    return result

# -----------------------------
# Workflow 2: Plot Configuration
# -----------------------------

SPATIAL_CONFIG_PROMPT_TEMPLATE = """\
You are a spatial plot configuration assistant. The user wants to create a "{plot_type}". 
Your role is to generate a valid JSON configuration for the selected plot type by accurately interpreting the spatial dataset metadata.

DEEPLY ANALYZE THE USER QUERY AND THE SPATIAL DATASET METADATA TO DETERMINE THE CORRECT PLOT CONFIGURATION.

Here is a description of how this plot type works and what arguments it needs:

Plot Type: {plot_type}
------------
{plot_description}

Below is the spatial dataset metadata which will help you determine valid field names, acceptable values, and constraints:
{dataset_metadata}

User Query:
{user_query}

### Your Task:
1. **Use Dataset Metadata:** Explicitly match field names and values to the metadata provided. If a user-provided value does not match, look for the closest valid match in the metadata.

2. **Correct Misspellings and Resolve Ambiguities:**
   - Correct gene names, annotation names, and other terms using your internal knowledge.
   - Disambiguate ambiguous terms using context and metadata.

3. **Generate Valid JSON:**
   - Return a JSON object that conforms exactly to the schema of the correct Pydantic class for "{plot_type}".
   - Exclude irrelevant or optional fields, unless specified in the user query or metadata.
   - Use the spatial data file path: {spatial_data_file}

4. **Strict Adherence to Schema:**
   - Use the correct field names, types, and defaults based on both the dataset metadata and the Pydantic model schema.
   - Only include fields relevant to "{plot_type}" from the spatial codebase.

5. **Output Format:**
   - Provide your output as a JSON object, unwrapped by Markdown formatting.
   - If a correction or adjustment is made, ensure the final JSON reflects the valid and corrected configuration.

#### JSON Configuration Schema (for reference):
{format_instructions}

**IMPORTANT:** Your final output must be ONLY the JSON object, with no surrounding text, explanations, or markdown formatting.
"""

def sanitize_spatial_config_paths(config_data: dict) -> dict:
    """
    Sanitize paths in the spatial configuration to hide absolute system paths.
    Only for display purposes and does not affect execution.
    """
    import copy
    sanitized_config = copy.deepcopy(config_data)
    
    # Check for spatial_data_file path and sanitize it if present
    if "spatial_data_file" in sanitized_config and sanitized_config["spatial_data_file"]:
        sanitized_config["spatial_data_file"] = "/path/to/spatial/sctriangulate.h5ad"
        
    return sanitized_config

async def spatial_plot_config_generator(plot_type: str, user_query: str) -> str:
    """
    Generates the configuration for a spatial plot based on the plot type and user query.
    """
    # Load spatial metadata
    dataset_metadata_str = get_spatial_metadata()

    # Get the correct Pydantic class and plot description
    chosen_class = get_spatial_plot_class(plot_type)
    plot_description = SPATIAL_PLOT_GUIDES.get(plot_type, "No guidance available for this plot type.")

    # Build a parser for the chosen class
    parser = PydanticOutputParser(pydantic_object=chosen_class)

    # Create the final prompt using the SPATIAL_CONFIG_PROMPT_TEMPLATE
    prompt_template = ChatPromptTemplate.from_messages(
        [
            ("system", SPATIAL_CONFIG_PROMPT_TEMPLATE),
            ("human", "{user_query}")
        ]
    ).partial(
        format_instructions=parser.get_format_instructions()
    )

    # Use advanced model for complex spatial plots
    if plot_type in {"plot_marker_expression_dotplot", "compare_annotations_via_heatmap"}:
        model = spatial_visualization_llm_advanced
    else:
        model = spatial_visualization_llm_base

    # Call the LLM and parse output using the chosen Pydantic class
    chain = prompt_template | model | parser

    # Invoke the chain asynchronously
    result_config = await chain.ainvoke({
        "user_query": user_query,
        "dataset_metadata": dataset_metadata_str,
        "plot_type": plot_type,
        "plot_description": plot_description,
        "spatial_data_file": SPATIAL_DATA_FILE
    })

    # Set the spatial data file path
    result_config.spatial_data_file = SPATIAL_DATA_FILE

    # Convert the resulting Pydantic model to valid JSON
    final_json = result_config.model_dump_json(indent=4)
    
    return final_json

# -----------------------------
# Main Spatial Visualization Function
# -----------------------------
async def Spatial_Data_Visualizer(user_query: str) -> dict:
    """
    Generates spatial visualizations based on user queries, creating plots and data files.
    """
    try:
        # 1) Run Workflow 1 - Plot Type Selection
        print("=== Starting Spatial Workflow 1 ===")
        w1_result = await run_spatial_workflow1(user_query)
        print("Spatial Workflow 1 completed. Results:", w1_result)
        
        # 2) Run Workflow 2 - Configuration Generation
        print("=== Starting Spatial Workflow 2 ===")
        try:
            config_json = await spatial_plot_config_generator(w1_result.plot_type, user_query)
            print("Spatial Workflow 2 completed. Config JSON generated:", config_json)
            config_data = json.loads(config_json)
            
            # Ensure output directory exists
            os.makedirs(SPATIAL_OUTPUT_DIR, exist_ok=True)
            
            # Save configuration
            output_json_path = os.path.join(SPATIAL_OUTPUT_DIR, "spatial_plot_config.json")
            with open(output_json_path, "w") as jf:
                jf.write(config_json)
            
            # Execute spatial plot generation
            plot_outputs_raw = spatial_main(json_input=output_json_path, output_dir=SPATIAL_OUTPUT_DIR)
            print("Spatial figure generation outputs:", plot_outputs_raw)
            
            # Process outputs
            png_entries = []
            csv_paths = []
            
            for plot in plot_outputs_raw:
                if isinstance(plot, list) and len(plot) == 2:
                    file_path = plot[0]
                    # Make path relative to SPATIAL_OUTPUT_DIR for URL construction
                    relative_file_path = os.path.relpath(file_path, SPATIAL_OUTPUT_DIR)
                    if file_path.endswith(".png"):
                        png_entries.append((file_path, f"{BASE_URL}/spatial_results/{relative_file_path.lstrip('/')}"))
                    elif file_path.endswith(".csv"):
                        csv_paths.append(f"{BASE_URL}/spatial_results/{relative_file_path.lstrip('/')}")
                else:
                    raise ValueError(f"Unexpected plot format: {plot}")
            
            # Build final output
            final_output = {
                "plot_type": w1_result.plot_type.upper(),
                "reason": w1_result.reason,
            }
            
            for i, (local_path, url) in enumerate(png_entries, start=1):
                final_output[f"png_path_{i}"] = url
            
            for j, csv in enumerate(csv_paths, start=1):
                final_output[f"csv_path_{j}"] = csv
            
            # Sanitize config paths before adding to final output
            sanitized_config = sanitize_spatial_config_paths(config_data)
            final_output["generated_config"] = sanitized_config
            
            print("Final spatial output ready:", final_output)
            return final_output
            
        except Exception as e:
            error_msg = f"Error in Spatial Workflow 2 or figure generation: {repr(e)}"
            print(error_msg)
            return {"error": error_msg}
            
    except Exception as e:
        error_msg = f"Error in spatial visualization pipeline: {repr(e)}"
        print(error_msg)
        return {"error": error_msg}

# For backward compatibility
spatial_visualization_tool = Spatial_Data_Visualizer 