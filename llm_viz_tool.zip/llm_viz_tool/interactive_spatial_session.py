#!/usr/bin/env python3
"""
Interactive Spatial Session - Fast spatial visualization with preloaded data
Now with Gradio Web Interface supporting images, data tables, and live code editing!
"""

import asyncio
import os
import sys
import time
import subprocess
import signal
import gradio as gr
import pandas as pd
from io import StringIO
import contextlib

# Add the spatial_dev directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from spatial_visualization_tool import Spatial_Data_Visualizer
from spatial_figure_generation import preload_spatial_system

# Global variables for session tracking
query_count = 0
total_time = 0
session_log = []

# Global variables for code editing
EDITABLE_FILES = {
    "interactive_spatial_session.py": "Main Gradio App",
    "spatial_visualization_tool.py": "LLM Visualization Tool", 
    "spatial_figure_generation.py": "Core Figure Generation",
    "spatial_utils.py": "Configuration Schemas",
    "Spatial_functions.R": "R Spatial Functions"
}

current_pid = os.getpid()

@contextlib.contextmanager
def capture_print():
    """Capture print statements for logging"""
    old_stdout = sys.stdout
    sys.stdout = captured_output = StringIO()
    try:
        yield captured_output
    finally:
        sys.stdout = old_stdout

def get_editable_file_path(filename):
    """Get the full path for an editable file"""
    base_dir = "/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev"
    return os.path.join(base_dir, filename)

def load_file_content(filename):
    """Load the content of a file for editing"""
    try:
        file_path = get_editable_file_path(filename)
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content, f"✅ Loaded {filename} ({len(content.splitlines())} lines)"
    except Exception as e:
        return "", f"❌ Error loading {filename}: {str(e)}"

def save_file_content(filename, content):
    """Save the edited content to a file"""
    try:
        file_path = get_editable_file_path(filename)
        
        # Create backup
        backup_path = f"{file_path}.backup"
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                backup_content = f.read()
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(backup_content)
        
        # Save new content
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        lines = len(content.splitlines())
        return f"✅ Saved {filename} ({lines} lines) - Backup created at {os.path.basename(backup_path)}"
    except Exception as e:
        return f"❌ Error saving {filename}: {str(e)}"

def restart_app():
    """Restart the Gradio app"""
    try:
        # Get the current script path
        script_path = os.path.abspath(__file__)
        
        # Prepare restart command
        python_exe = sys.executable
        restart_cmd = [python_exe, script_path]
        
        # Schedule restart
        def delayed_restart():
            time.sleep(2)  # Give time for response to be sent
            os.execv(python_exe, [python_exe] + [script_path])
        
        # Start restart in background
        import threading
        restart_thread = threading.Thread(target=delayed_restart)
        restart_thread.daemon = True
        restart_thread.start()
        
        return "🔄 App restarting... Please try refreshing your browser after 2 minutes."
        
    except Exception as e:
        return f"❌ Restart failed: {str(e)}"

def get_file_info():
    """Get information about all editable files"""
    info_lines = ["📁 Editable Files:\n"]
    for filename, description in EDITABLE_FILES.items():
        file_path = get_editable_file_path(filename)
        if os.path.exists(file_path):
            stat = os.stat(file_path)
            size = stat.st_size
            mtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime))
            info_lines.append(f"✅ {filename}: {description}")
            info_lines.append(f"   Size: {size:,} bytes | Modified: {mtime}")
        else:
            info_lines.append(f"❌ {filename}: Not found")
        info_lines.append("")
    
    return "\n".join(info_lines)

def check_syntax(filename, content):
    """Check Python syntax for Python files"""
    if not filename.endswith('.py'):
        return "⚠️ Syntax check only available for Python files"
    
    try:
        compile(content, filename, 'exec')
        return "✅ Python syntax is valid"
    except SyntaxError as e:
        return f"❌ Syntax error on line {e.lineno}: {e.msg}"
    except Exception as e:
        return f"⚠️ Syntax check error: {str(e)}"

def load_csv_or_tsv(file_path):
    """Load CSV or TSV file and return as pandas DataFrame"""
    try:
        if file_path.endswith('.tsv'):
            df = pd.read_csv(file_path, sep='\t')
        else:
            df = pd.read_csv(file_path)
        return df
    except Exception as e:
        print(f"Error loading data file {file_path}: {e}")
        return None

def initialize_system():
    """Initialize the spatial system and return status"""
    print("🚀 INITIALIZING SPATIAL VISUALIZATION SYSTEM")
    print("="*60)
    print("🔄 Preloading spatial data for fast queries...")
    
    try:
        preload_spatial_system()
        status = "✅ System ready! Enter your spatial query below."
        print("🚀 Web interface ready!")
        return status
    except Exception as e:
        status = f"❌ Initialization failed: {str(e)}"
        print(status)
        return status

async def process_spatial_query(query):
    """Process a spatial query and return results including both images and data tables"""
    global query_count, total_time, session_log
    
    if not query or query.strip() == "":
        return None, None, "Please enter a valid query.", ""
    
    query = query.strip()
    query_count += 1
    
    # Capture all output
    log_output = StringIO()
    
    with contextlib.redirect_stdout(log_output):
        print(f"🔍 Query #{query_count}: {query}")
        print(f"⚡ Processing...")
        
        start_time = time.time()
        
        try:
            result = await Spatial_Data_Visualizer(query)
            execution_time = time.time() - start_time
            total_time += execution_time
            
            print(f"⏱️  Execution time: {execution_time:.2f}s")
            
            if "error" in result:
                print(f"❌ Error: {result['error']}")
                session_log.append(f"Query {query_count}: ERROR - {result['error']}")
                return None, None, f"❌ Error: {result['error']}", log_output.getvalue()
            else:
                print(f"✅ Success: {result['plot_type']}")
                print(f"📊 Reason: {result['reason']}")
                
                # Get PNG and CSV files
                png_files = [k for k in result.keys() if k.startswith('png_path_')]
                csv_files = [k for k in result.keys() if k.startswith('csv_path_')]
                
                if png_files:
                    print(f"🖼️  Generated {len(png_files)} visualization(s)")
                    for png_key in png_files:
                        print(f"   📸 {result[png_key]}")
                
                if csv_files:
                    print(f"📄 Generated {len(csv_files)} data file(s)")
                    for csv_key in csv_files:
                        print(f"   📋 {result[csv_key]}")
                
                # Session stats
                avg_time = total_time / query_count
                print(f"\n📊 Session Stats:")
                print(f"   Queries: {query_count} | Total: {total_time:.1f}s | Avg: {avg_time:.1f}s")
                
                session_log.append(f"Query {query_count}: {result['plot_type']} ({execution_time:.1f}s)")
                
                # Prepare outputs for Gradio
                image_path = None
                data_table = None
                
                # Handle PNG files
                if png_files:
                    # Convert URL to local file path for Gradio
                    png_url = result[png_files[0]]
                    filename = png_url.split('/')[-1]
                    local_path = f"/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/results/{filename}"
                    
                    if os.path.exists(local_path):
                        image_path = local_path
                        print(f"🖼️  Image ready for display: {filename}")
                    else:
                        print(f"⚠️  Plot file not found: {filename}")
                
                # Handle CSV/TSV files
                if csv_files:
                    # Load the first CSV file for display
                    csv_url = result[csv_files[0]]
                    filename = csv_url.split('/')[-1]
                    local_csv_path = f"/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/results/{filename}"
                    
                    if os.path.exists(local_csv_path):
                        data_table = load_csv_or_tsv(local_csv_path)
                        if data_table is not None:
                            print(f"📊 Data table loaded: {data_table.shape[0]} rows × {data_table.shape[1]} columns")
                            # Limit display to first 100 rows for performance
                            if len(data_table) > 100:
                                data_table = data_table.head(100)
                                print(f"📊 Displaying first 100 rows (of {len(data_table)} total)")
                        else:
                            print(f"⚠️  Failed to load data file: {filename}")
                    else:
                        print(f"⚠️  Data file not found: {filename}")
                
                # Create status message
                status_parts = [f"✅ {result['plot_type']} - {execution_time:.1f}s"]
                if image_path:
                    status_parts.append("🖼️ Visualization displayed")
                if data_table is not None:
                    status_parts.append(f"📊 Data table ({data_table.shape[0]}×{data_table.shape[1]})")
                
                status_message = " | ".join(status_parts)
                
                return image_path, data_table, status_message, log_output.getvalue()
                
        except Exception as e:
            execution_time = time.time() - start_time
            print(f"❌ Exception after {execution_time:.1f}s: {str(e)}")
            import traceback
            print("🔍 Traceback:")
            traceback.print_exc()
            session_log.append(f"Query {query_count}: EXCEPTION - {str(e)}")
            return None, None, f"❌ Exception: {str(e)}", log_output.getvalue()

def sync_process_query(query):
    """Synchronous wrapper for the async query processor"""
    return asyncio.run(process_spatial_query(query))

def create_gradio_interface():
    """Create and launch the Gradio interface with support for images, data tables, and code editing"""
    
    # Initialize system before creating interface
    init_status = initialize_system()
    
    with gr.Blocks(title="🔬 Spatial Data Visualizer + Code Editor", theme=gr.themes.Soft()) as interface:
        
        gr.Markdown("""
        # 🔬 Interactive Spatial Visualization Tool + Live Code Editor
        
        **Fast spatial analysis with preloaded data + real-time development environment!**
        """)
        
        # Create tabs for different functionalities
        with gr.Tab("🚀 Spatial Visualization"):
            gr.Markdown("""
            ### 💡 Example Queries:
            - *"Show spatial distribution of AT1 cells"* → 🖼️ Spatial plot
            - *"Plot VEGFA expression in Xenium"* → 🖼️ Gene expression plot
            - *"Create UMAP for cell types"* → 🖼️ UMAP visualization
            - *"Find markers for AT2 cells"* → 📊 Marker genes table
            - *"Compare SPARCL1 correlation between platforms"* → 🖼️ Correlation plot
            - *"Rank genes by cross-platform correlation"* → 📊 Gene ranking table
            """)
            
            with gr.Row():
                with gr.Column(scale=2):
                    query_input = gr.Textbox(
                        label="🔍 Enter your spatial query:",
                        placeholder="e.g., 'Show spatial distribution of AT1 cells'",
                        lines=2
                    )
                    
                    submit_btn = gr.Button("🚀 Generate Visualization", variant="primary", size="lg")
                    
                    status_output = gr.Textbox(
                        label="📊 Status:",
                        value=init_status,
                        lines=2,
                        interactive=False
                    )
                
                with gr.Column(scale=3):
                    image_output = gr.Image(
                        label="🖼️ Generated Visualization:",
                        type="filepath",
                        height=400
                    )
            
            # Add data table component
            with gr.Row():
                with gr.Column():
                    data_output = gr.Dataframe(
                        label="📊 Generated Data Table:",
                        wrap=True,
                        interactive=False
                    )
            
            with gr.Row():
                with gr.Column():
                    log_output = gr.Textbox(
                        label="📋 Detailed Log:",
                        lines=12,
                        max_lines=20,
                        interactive=False,
                        show_copy_button=True
                    )
            
            # Event handlers - now returning 4 outputs: image, data, status, log
            submit_btn.click(
                fn=sync_process_query,
                inputs=[query_input],
                outputs=[image_output, data_output, status_output, log_output]
            )
            
            query_input.submit(
                fn=sync_process_query,
                inputs=[query_input],
                outputs=[image_output, data_output, status_output, log_output]
            )
            
            # Add some example buttons
            gr.Markdown("### 🎯 Quick Examples:")
            with gr.Row():
                example_1 = gr.Button("AT1 Spatial Distribution", size="sm")
                example_2 = gr.Button("VEGFA in Xenium", size="sm")
                example_3 = gr.Button("UMAP Cell Types", size="sm")
                example_4 = gr.Button("AT2 Markers", size="sm")
            
            with gr.Row():
                example_5 = gr.Button("Gene Correlation Ranking", size="sm")
                example_6 = gr.Button("SPARCL1 Correlation Plot", size="sm")
                example_7 = gr.Button("Cell Type Stability", size="sm")
                example_8 = gr.Button("Inflammatory FB Markers", size="sm")
            
            # Example button handlers
            example_1.click(lambda: "Show spatial distribution of AT1 cells", outputs=[query_input])
            example_2.click(lambda: "Plot VEGFA expression in Xenium", outputs=[query_input])
            example_3.click(lambda: "Create UMAP colored by cell types", outputs=[query_input])
            example_4.click(lambda: "Find top marker genes for AT2 cells", outputs=[query_input])
            example_5.click(lambda: "Rank genes by cross-platform correlation", outputs=[query_input])
            example_6.click(lambda: "Compare SPARCL1 correlation between platforms", outputs=[query_input])
            example_7.click(lambda: "Analyze cell type stability across clustering methods", outputs=[query_input])
            example_8.click(lambda: "Find specific markers for inflammatory fibroblasts", outputs=[query_input])
        
        # New Code Editor Tab
        with gr.Tab("💻 Code Editor"):
            gr.Markdown("""
            ### 🛠️ Live Code Editor & App Management
            Edit, save, and restart the app for iterative development!
            """)
            
            with gr.Row():
                with gr.Column(scale=1):
                    file_selector = gr.Dropdown(
                        choices=list(EDITABLE_FILES.keys()),
                        value=list(EDITABLE_FILES.keys())[0],
                        label="📁 Select File to Edit:",
                        info="Choose which file to edit"
                    )
                    
                    load_btn = gr.Button("📂 Load File", variant="secondary")
                    save_btn = gr.Button("💾 Save Changes", variant="primary")
                    syntax_btn = gr.Button("🔍 Check Syntax", variant="secondary")
                    
                    gr.Markdown("---")
                    restart_btn = gr.Button("🔄 Restart App", variant="stop", size="lg")
                    
                    file_status = gr.Textbox(
                        label="📋 File Status:",
                        lines=3,
                        interactive=False
                    )
                
                with gr.Column(scale=3):
                    code_editor = gr.Code(
                        label="📝 Code Editor:",
                        language="python",
                        lines=25,
                        interactive=True
                    )
            
            with gr.Row():
                with gr.Column():
                    file_info_display = gr.Textbox(
                        label="📊 File Information:",
                        value=get_file_info(),
                        lines=10,
                        interactive=False
                    )
            
            # Code editor event handlers
            def load_file_handler(filename):
                content, status = load_file_content(filename)
                return content, status
            
            def save_file_handler(filename, content):
                status = save_file_content(filename, content)
                info = get_file_info()
                return status, info
            
            def syntax_check_handler(filename, content):
                return check_syntax(filename, content)
            
            load_btn.click(
                fn=load_file_handler,
                inputs=[file_selector],
                outputs=[code_editor, file_status]
            )
            
            save_btn.click(
                fn=save_file_handler,
                inputs=[file_selector, code_editor],
                outputs=[file_status, file_info_display]
            )
            
            syntax_btn.click(
                fn=syntax_check_handler,
                inputs=[file_selector, code_editor],
                outputs=[file_status]
            )
            
            restart_btn.click(
                fn=restart_app,
                outputs=[file_status]
            )
            
            # Auto-load first file on startup
            file_selector.change(
                fn=load_file_handler,
                inputs=[file_selector],
                outputs=[code_editor, file_status]
            )
        
        # System Info Tab
        with gr.Tab("ℹ️ System Info"):
            gr.Markdown("""
            ### 📊 System Information & Session Stats
            """)
            
            system_info = gr.Textbox(
                label="🖥️ System Status:",
                value=f"""
🔬 Spatial Data Visualizer v2.0 - Live Development Edition

📍 Current Directory: {os.getcwd()}
🐍 Python: {sys.version}
🆔 Process ID: {current_pid}
📁 Base Path: /Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/

🛠️ Editable Files: {len(EDITABLE_FILES)}
📊 Session Queries: {query_count}
⏱️ Total Time: {total_time:.1f}s

🚀 Features:
✅ Fast spatial visualization with preloaded data
✅ Live code editing with syntax checking
✅ Hot restart capability
✅ Image and data table display
✅ Comprehensive logging
                """.strip(),
                lines=15,
                interactive=False
            )
            
            refresh_info_btn = gr.Button("🔄 Refresh Info", variant="secondary")
            
            def refresh_system_info():
                return f"""
🔬 Spatial Data Visualizer v2.0 - Live Development Edition

📍 Current Directory: {os.getcwd()}
🐍 Python: {sys.version}
🆔 Process ID: {os.getpid()}
📁 Base Path: /Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/

🛠️ Editable Files: {len(EDITABLE_FILES)}
📊 Session Queries: {query_count}
⏱️ Total Time: {total_time:.1f}s
📋 Session Log: {len(session_log)} entries

🚀 Features:
✅ Fast spatial visualization with preloaded data
✅ Live code editing with syntax checking  
✅ Hot restart capability
✅ Image and data table display
✅ Comprehensive logging

📝 Recent Queries:
{chr(10).join(session_log[-5:]) if session_log else "No queries yet"}
                """.strip()
            
            refresh_info_btn.click(
                fn=refresh_system_info,
                outputs=[system_info]
            )
    
    return interface

def start_gradio_app():
    """Start the Gradio web application"""
    print("🌐 Starting Gradio Web Interface with Live Code Editor...")
    print(f"🆔 Process ID: {current_pid}")
    
    interface = create_gradio_interface()
    
    # Launch the interface
    interface.launch(
        server_name="0.0.0.0",  # Allow external access
        server_port=7860,       # Default Gradio port
        share=False,            # Set to True to create public link
        debug=True,             # Show detailed logs
        show_error=True         # Show error messages
    )

if __name__ == "__main__":
    start_gradio_app()