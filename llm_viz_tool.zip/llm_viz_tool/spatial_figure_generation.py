# spatial_figure_generation.py
import os
import json
import time
import rpy2.robjects as ro
from rpy2.robjects.packages import importr
from rpy2.robjects import pandas2ri
from rpy2.robjects.conversion import localconverter
import argparse
import uuid

# Import R packages
base = importr('base')
utils = importr('utils')

def load_r_functions():
    """Load R spatial functions"""
    r_script_path = "/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/Spatial_functions.R"
    ro.r(f'source("{r_script_path}")')
    print("R spatial functions loaded successfully")

def load_spatial_data():
    """Load spatial data and create SingleCellExperiment object using scanpy + pandas"""
    import scanpy as sc
    import pandas as pd
    import numpy as np
    
    data_path = "/Users/rajlq7/Downloads/LungChat/LungMAP_scExplore/spatial_dev/sctriangulate.h5ad"
    
    print("Loading spatial data with scanpy...")
    adata = sc.read_h5ad(data_path)
    print(f"✅ Loaded data: {adata.shape[0]} cells, {adata.shape[1]} genes")
    
    # Create SCE object using manual conversion (no zellkonverter)
    print("Creating SingleCellExperiment object...")
    
    # Use subset for efficiency but keep all metadata
    n_genes_subset = min(1000, adata.shape[1])
    expr_matrix = adata.X[:, :n_genes_subset]
    
    if hasattr(expr_matrix, 'toarray'):
        expr_matrix = expr_matrix.toarray()
    
    # Create DataFrames
    expr_df = pd.DataFrame(
        expr_matrix.T,  # Genes x Cells for R
        index=adata.var.index[:n_genes_subset],
        columns=adata.obs.index
    )
    
    cell_meta = adata.obs.copy()
    gene_meta = pd.DataFrame({
        'gene_id': adata.var.index[:n_genes_subset],
        'gene_symbol': adata.var.index[:n_genes_subset]
    }, index=adata.var.index[:n_genes_subset])
    
    # Convert to R using localconverter (no deprecated pandas2ri.activate())
    with localconverter(ro.default_converter + pandas2ri.converter):
        r_expr = ro.conversion.py2rpy(expr_df)
        r_cell_meta = ro.conversion.py2rpy(cell_meta)
        r_gene_meta = ro.conversion.py2rpy(gene_meta)
    
    # Create SCE object in R
    ro.globalenv['expr_matrix'] = r_expr
    ro.globalenv['cell_meta'] = r_cell_meta
    ro.globalenv['gene_meta'] = r_gene_meta
    
    sce_code = '''
    suppressPackageStartupMessages({
        library(SingleCellExperiment)
        library(SummarizedExperiment)
        library(dplyr)
        library(ggplot2)
        library(scales)
    })
    
    sce_obj <- SingleCellExperiment(
        assays = list(X = as.matrix(expr_matrix)),
        colData = cell_meta,
        rowData = gene_meta
    )
    
    cat("SCE object created with dimensions:", dim(sce_obj), "\\n")
    print("Spatial data loaded successfully")
    print(paste("Data shape:", nrow(sce_obj), "cells x", ncol(sce_obj), "genes"))
    print(paste("Available annotations:", paste(colnames(colData(sce_obj)), collapse=", ")))
    '''
    
    try:
        ro.r(sce_code)
        print("✅ SingleCellExperiment object created successfully")
    except Exception as e:
        print(f"❌ SCE creation failed: {e}")
        raise

def execute_spatial_function(config_data: dict, output_dir: str) -> list:
    """Execute the appropriate spatial function based on configuration"""
    plot_type = config_data["plot_type"]
    generated_files = []
    
    print(f"Executing spatial function: {plot_type}")
    
    try:
        if plot_type == "plot_spatial":
            files = execute_plot_spatial(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "plot_umap":
            files = execute_plot_umap(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "plot_gene_spatial":
            files = execute_plot_gene_spatial(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "rank_cross_platform_gene_correlation":
            files = execute_rank_cross_platform_gene_correlation(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "plot_cross_platform_gene_correlation":
            files = execute_plot_cross_platform_gene_correlation(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "rank_marker_specificity":
            files = execute_rank_marker_specificity(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "find_top_markers_for_celltype":
            files = execute_find_top_markers_for_celltype(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "scTriangulate_summarize_celltype_stability":
            files = execute_scTriangulate_summarize_celltype_stability(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "plot_ARI_dotplot":
            files = execute_plot_ARI_dotplot(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "plot_marker_expression_dotplot":
            files = execute_plot_marker_expression_dotplot(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "plot_cluster_composition_groupedbar":
            files = execute_plot_cluster_composition_groupedbar(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "compare_annotations_via_heatmap":
            files = execute_compare_annotations_via_heatmap(config_data, output_dir)
            generated_files.extend(files)
            
        elif plot_type == "visualize_matched_pairs_scatter":
            files = execute_visualize_matched_pairs_scatter(config_data, output_dir)
            generated_files.extend(files)
            
        else:
            raise ValueError(f"Unsupported plot type: {plot_type}")
            
    except Exception as e:
        print(f"Error executing {plot_type}: {str(e)}")
        raise
    
    return generated_files

def execute_plot_spatial(config: dict, output_dir: str) -> list:
    """Execute plot_spatial function"""
    annotation = config["annotation"]
    point_size = config.get("point_size", 0.5)
    title = config.get("title", "NULL")
    
    # Convert None/NULL values for R
    title_r = f'"{title}"' if title and title != "NULL" else "NULL"
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"spatial_plot_{annotation}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("plot_spatial") && exists("sce_obj")) {{
        cat("Creating spatial plot for annotation: {annotation}\\n")
        
        p <- plot_spatial(
            obj = sce_obj,
            annotation = "{annotation}",
            point_size = {point_size},
            title = {title_r}
        )
        
        ggsave("{output_file}", p, width = 12, height = 10, dpi = 150, bg = "white")
        cat("Spatial plot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Spatial plot for {annotation}"]]

def execute_plot_umap(config: dict, output_dir: str) -> list:
    """Execute plot_umap function"""
    annotation = config["annotation"]
    platform = config.get("platform", "Visium")  # Default to Visium
    point_size = config.get("point_size", 0.5)
    
    # platform is required for plot_umap, default to Visium if not specified
    if not platform or platform == "NULL":
        platform = "Visium"
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"umap_plot_{platform}_{annotation}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("plot_umap") && exists("sce_obj")) {{
        cat("Creating UMAP plot for annotation: {annotation} on {platform}\\n")
        
        p <- plot_umap(
            obj = sce_obj,
            platform = "{platform}",
            annotation = "{annotation}",
            point_size = {point_size}
        )
        
        ggsave("{output_file}", p, width = 12, height = 10, dpi = 150, bg = "white")
        cat("UMAP plot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"UMAP plot for {annotation} ({platform})"]]

def execute_plot_gene_spatial(config: dict, output_dir: str) -> list:
    """Execute plot_gene_spatial function"""
    gene = config["gene"]
    platform = config.get("platform", "Visium")  # Default to Visium
    point_size = config.get("point_size", 0.5)
    title = config.get("title", "NULL")
    
    # Extract base gene name if it has platform suffix
    if gene.endswith("_xenium") or gene.endswith("_visium"):
        base_gene = gene.rsplit("_", 1)[0]
    else:
        base_gene = gene
    
    # Default to Visium if not specified
    if not platform or platform == "NULL":
        platform = "Visium"
    
    title_r = f'"{title}"' if title and title != "NULL" else "NULL"
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"gene_spatial_{base_gene}_{platform}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("plot_gene_spatial") && exists("sce_obj")) {{
        cat("Creating spatial gene plot for: {base_gene} ({platform})\\n")
        
        p <- plot_gene_spatial(
            obj = sce_obj,
            gene = "{base_gene}",
            platform = "{platform}",
            point_size = {point_size},
            title = {title_r}
        )
        
        ggsave("{output_file}", p, width = 12, height = 10, dpi = 150, bg = "white")
        cat("Spatial gene plot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Spatial gene plot for {base_gene} ({platform})"]]

def execute_rank_cross_platform_gene_correlation(config: dict, output_dir: str) -> list:
    """Execute rank_cross_platform_gene_correlation function"""
    top_genes = config.get("top_genes", 5)
    layer = config.get("layer", "X")
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"cross_platform_gene_ranking_{unique_id}.csv")
    
    ro.r(f'''
    if (exists("rank_cross_platform_gene_correlation") && exists("sce_obj")) {{
        cat("Ranking cross-platform gene correlations (top {top_genes})\\n")
        
        result <- rank_cross_platform_gene_correlation(
            obj = sce_obj,
            top_genes = {top_genes},
            layer = "{layer}"
        )
        
        # Convert named vector to data frame
        result_df <- data.frame(
            Gene = names(result),
            Correlation = as.numeric(result)
        )
        
        write.csv(result_df, "{output_file}", row.names = FALSE)
        cat("Cross-platform ranking saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Cross-platform gene correlation ranking (top {top_genes})"]]

def execute_plot_cross_platform_gene_correlation(config: dict, output_dir: str) -> list:
    """Execute plot_cross_platform_gene_correlation function"""
    gene_name = config["gene_name"]
    ID1_col = config.get("ID1_col", "Visium_ID")
    ID2_col = config.get("ID2_col", "Xenium_ID")
    hline = config.get("hline", 0.9)
    y_range = config.get("y_range", [0, 1])
    title = config.get("title", "NULL")
    
    title_r = f'"{title}"' if title and title != "NULL" else "NULL"
    y_range_r = f"c({y_range[0]}, {y_range[1]})"
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"cross_platform_correlation_{gene_name}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("plot_cross_platform_gene_correlation") && exists("sce_obj")) {{
        cat("Creating cross-platform correlation plot for gene: {gene_name}\\n")
        
        p <- plot_cross_platform_gene_correlation(
            obj = sce_obj,
            gene_name = "{gene_name}",
            ID1_col = "{ID1_col}",
            ID2_col = "{ID2_col}",
            hline = {hline},
            y_range = {y_range_r},
            title = {title_r}
        )
        
        ggsave("{output_file}", p, width = 12, height = 8, dpi = 150, bg = "white")
        cat("Cross-platform correlation plot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Cross-platform correlation plot for {gene_name}"]]

def execute_rank_marker_specificity(config: dict, output_dir: str) -> list:
    """Execute rank_marker_specificity function"""
    platform = config["platform"]
    annotation = config["annotation"]
    n_genes = config.get("n_genes", 10)
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"marker_specificity_{platform}_{annotation}_{unique_id}.csv")
    
    ro.r(f'''
    if (exists("rank_marker_specificity") && exists("sce_obj")) {{
        cat("Ranking marker specificity for {platform} {annotation}\\n")
        
        result <- rank_marker_specificity(
            obj = sce_obj,
            platform = "{platform}",
            annotation = "{annotation}",
            n_genes = {n_genes}
        )
        
        write.csv(result, "{output_file}", row.names = FALSE)
        cat("Marker specificity ranking saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Marker specificity ranking for {platform} {annotation}"]]

def execute_find_top_markers_for_celltype(config: dict, output_dir: str) -> list:
    """Execute find_top_markers_for_celltype function"""
    celltype = config["celltype"]
    annotation_col = config["annotation_col"]
    platform_suffixes = config["platform_suffixes"]
    top_n = config.get("top_n", 10)
    
    unique_id = str(uuid.uuid4())[:8]
    platform_str = "_".join(platform_suffixes)
    output_file = os.path.join(output_dir, f"top_markers_{celltype}_{platform_str}_{unique_id}.csv")
    
    # Convert platform_suffixes to R vector
    suffixes_r = "c(" + ", ".join([f'"{s}"' for s in platform_suffixes]) + ")"
    
    ro.r(f'''
    if (exists("find_top_markers_for_celltype") && exists("sce_obj")) {{
        cat("Finding top markers for {celltype} in {platform_str}\\n")
        
        result <- find_top_markers_for_celltype(
            obj = sce_obj,
            celltype = "{celltype}",
            annotation_col = "{annotation_col}",
            platform_suffixes = {suffixes_r},
            top_n = {top_n}
        )
        
        write.csv(result, "{output_file}", row.names = FALSE)
        cat("Top markers saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Top markers for {celltype} in {platform_str}"]]

def execute_scTriangulate_summarize_celltype_stability(config: dict, output_dir: str) -> list:
    """Execute scTriangulate_summarize_celltype_stability function"""
    labels_list = config["labels_list"]
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"celltype_stability_{unique_id}.csv")
    
    # Convert dict to R list with proper format for the function
    labels_r = "list("
    for key, values in labels_list.items():
        values_str = "c(" + ", ".join([f'"{v}"' for v in values]) + ")"
        labels_r += f'"{key}" = {values_str}, '
    labels_r = labels_r.rstrip(', ') + ")"
    
    ro.r(f'''
    if (exists("scTriangulate_summarize_celltype_stability") && exists("sce_obj")) {{
        cat("Summarizing cell type stability\\n")
        
        # Create labels list as required by the function
        labels_list <- {labels_r}
        
        # Debug: print the structure
        cat("Labels list structure:\\n")
        str(labels_list)
        
        result <- scTriangulate_summarize_celltype_stability(
            obj = sce_obj,
            labels_list = labels_list
        )
        
        write.csv(result, "{output_file}", row.names = FALSE)
        cat("Cell type stability summary saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, "Cell type stability summary"]]

def execute_plot_ARI_dotplot(config: dict, output_dir: str) -> list:
    """Execute plot_ARI_dotplot function"""
    annotation1 = config["annotation1"]
    annotation2 = config["annotation2"]
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"ARI_dotplot_{annotation1}_{annotation2}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("plot_ARI_dotplot") && exists("sce_obj")) {{
        if ("{annotation1}" %in% colnames(colData(sce_obj)) && 
            "{annotation2}" %in% colnames(colData(sce_obj))) {{
            cat("Creating ARI dotplot for {annotation1} vs {annotation2}\\n")
            
            p <- plot_ARI_dotplot(
                obj = sce_obj,
                annotation1 = "{annotation1}",
                annotation2 = "{annotation2}"
            )
            
            ggsave("{output_file}", p, width = 10, height = 8, dpi = 150, bg = "white")
            cat("ARI dotplot saved to: {output_file}\\n")
        }} else {{
            stop("Required annotation columns not found in data")
        }}
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"ARI dotplot for {annotation1} vs {annotation2}"]]

def execute_plot_marker_expression_dotplot(config: dict, output_dir: str) -> list:
    """Execute plot_marker_expression_dotplot function"""
    genes = config["genes"]
    platform = config["platform"]
    annotation = config["annotation"]
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"marker_expression_dotplot_{platform}_{unique_id}.png")
    
    # Convert list to R vector
    genes_r = "c(" + ", ".join([f'"{g}"' for g in genes]) + ")"
    
    ro.r(f'''
    if (exists("plot_marker_expression_dotplot") && exists("sce_obj")) {{
        cat("Creating marker expression dotplot for {platform}\\n")
        
        p <- plot_marker_expression_dotplot(
            obj = sce_obj,
            genes = {genes_r},
            platform = "{platform}",
            annotation = "{annotation}"
        )
        
        ggsave("{output_file}", p, width = 12, height = 8, dpi = 150, bg = "white")
        cat("Marker expression dotplot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Marker expression dotplot for {platform}"]]

def execute_plot_cluster_composition_groupedbar(config: dict, output_dir: str) -> list:
    """Execute plot_cluster_composition_groupedbar function"""
    annotation = config["annotation"]
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"cluster_composition_{annotation}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("plot_cluster_composition_groupedbar") && exists("sce_obj")) {{
        cat("Creating cluster composition plot for {annotation}\\n")
        
        p <- plot_cluster_composition_groupedbar(
            obj = sce_obj,
            annotation = "{annotation}"
        )
        
        ggsave("{output_file}", p, width = 12, height = 8, dpi = 150, bg = "white")
        cat("Cluster composition plot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Cluster composition for {annotation}"]]

def execute_compare_annotations_via_heatmap(config: dict, output_dir: str) -> list:
    """Execute compare_annotations_via_heatmap function"""
    annotation1 = config["annotation1"]
    annotation2 = config["annotation2"]
    normalize = config.get("normalize", "row")
    title = config.get("title", "NULL")
    
    title_r = f'"{title}"' if title and title != "NULL" else "NULL"
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"annotation_heatmap_{annotation1}_{annotation2}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("compare_annotations_via_heatmap") && exists("sce_obj")) {{
        if ("{annotation1}" %in% colnames(colData(sce_obj)) && 
            "{annotation2}" %in% colnames(colData(sce_obj))) {{
            cat("Creating annotation comparison heatmap: {annotation1} vs {annotation2}...\\n")
            
            # Ensure proper data conversion to avoid list vs vector issues
            colData(sce_obj)${annotation1} <- as.character(colData(sce_obj)${annotation1})
            colData(sce_obj)${annotation2} <- as.character(colData(sce_obj)${annotation2})
            
            # Debug the exact issue with detailed step-by-step analysis
            cat("Creating heatmap with manual data preparation...\\n")
            
            # Extract and prepare data manually to avoid dplyr issues
            meta_data <- as.data.frame(colData(sce_obj))
            meta_clean <- meta_data[!is.na(meta_data[, "{annotation1}"]) & 
                                   !is.na(meta_data[, "{annotation2}"]), ]
            
            # Create contingency table manually
            cont_table <- table(meta_clean[, "{annotation1}"], meta_clean[, "{annotation2}"])
            
            # Convert to data frame for ggplot
            df_plot <- as.data.frame(cont_table)
            names(df_plot) <- c("Annotation1", "Annotation2", "Value")
            
            if ("{normalize}" == "row") {{
                df_plot <- df_plot %>%
                    group_by(Annotation1) %>%
                    mutate(Value = Value / sum(Value)) %>%
                    ungroup()
            }} else if ("{normalize}" == "column") {{
                df_plot <- df_plot %>%
                    group_by(Annotation2) %>%
                    mutate(Value = Value / sum(Value)) %>%
                    ungroup()
            }}
            
            # Create heatmap
            p <- ggplot(df_plot, aes(x = Annotation2, y = Annotation1, fill = Value)) +
                geom_tile(color = "white") +
                scale_fill_distiller(palette = "Blues", direction = 1, na.value = "grey90") +
                geom_text(aes(label = ifelse(Value == 0, "", comma(round(Value, 2)))), size = 3.2) +
                theme_bw(base_size = 12) +
                theme(
                    axis.text.x = element_text(angle = 45, hjust = 1),
                    panel.grid = element_blank(),
                    plot.background = element_rect(fill = "white", colour = NA),
                    panel.background = element_rect(fill = "white", colour = NA)
                ) +
                labs(
                    x = "{annotation2}",
                    y = "{annotation1}",
                    fill = ifelse("{normalize}" == "none", "Count", "Proportion"),
                    title = ifelse({title_r} == "NULL", "Annotation Comparison Heatmap", {title_r})
                )
            
            ggsave("{output_file}", p, width = 12, height = 10, dpi = 150, bg = "white")
            cat("Annotation heatmap saved to: {output_file}\\n")
        }} else {{
            stop("Required annotation columns not found in data")
        }}
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Annotation comparison heatmap: {annotation1} vs {annotation2}"]]

def execute_visualize_matched_pairs_scatter(config: dict, output_dir: str) -> list:
    """Execute visualize_matched_pairs_scatter function"""
    gene = config["gene"]
    annotation = config["annotation"]
    
    unique_id = str(uuid.uuid4())[:8]
    output_file = os.path.join(output_dir, f"matched_pairs_scatter_{gene}_{unique_id}.png")
    
    ro.r(f'''
    if (exists("visualize_matched_pairs_scatter") && exists("sce_obj")) {{
        cat("Creating matched pairs scatter plot for {gene}\\n")
        
        p <- visualize_matched_pairs_scatter(
            obj = sce_obj,
            gene = "{gene}",
            annotation = "{annotation}"
        )
        
        ggsave("{output_file}", p, width = 10, height = 8, dpi = 150, bg = "white")
        cat("Matched pairs scatter plot saved to: {output_file}\\n")
    }} else {{
        stop("Required functions or data not available")
    }}
    ''')
    
    return [[output_file, f"Matched pairs scatter plot for {gene}"]]

# Global flag to track if data is preloaded
_DATA_PRELOADED = False

def check_if_data_preloaded():
    """Check if SCE object already exists in R global environment"""
    try:
        # Check if sce_obj exists in R
        result = ro.r('exists("sce_obj")')
        return bool(result[0])
    except:
        return False

def preload_spatial_system():
    """
    Preload the spatial system once for fast interactive queries.
    Call this function once at the start of your session.
    """
    global _DATA_PRELOADED
    
    if check_if_data_preloaded() or _DATA_PRELOADED:
        print("✅ Spatial system already preloaded")
        return
    
    print("🔄 Preloading spatial system for fast queries...")
    start_time = time.time()
    
    try:
        with localconverter(pandas2ri.converter):
            # Load R functions and data once
            print("📋 Loading R functions...")
            load_r_functions()
            
            print("📊 Loading spatial data...")
            load_spatial_data()
            
            _DATA_PRELOADED = True
            
        load_time = time.time() - start_time
        print(f"✅ Spatial system preloaded in {load_time:.2f} seconds")
        print("🚀 Ready for fast interactive queries!")
        
    except Exception as e:
        print(f"❌ Failed to preload spatial system: {e}")
        raise

def main(json_input: str, output_dir: str = "results", skip_data_loading: bool = False) -> list:
    """
    Main function to execute spatial visualization based on JSON configuration.
    
    Args:
        json_input: Path to JSON configuration file
        output_dir: Directory to save output files
        skip_data_loading: If True, skip data loading (assumes data is preloaded)
        
    Returns:
        List of generated files
    """
    global _DATA_PRELOADED
    
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    # Load configuration
    with open(json_input, 'r') as f:
        config_data = json.load(f)
    
    print(f"Processing spatial configuration: {config_data['plot_type']}")
    
    try:
        # Use proper conversion context to avoid deprecation warnings
        with localconverter(pandas2ri.converter):
            
            # Check if we can skip data loading
            data_already_loaded = check_if_data_preloaded() or _DATA_PRELOADED
            
            if not skip_data_loading and not data_already_loaded:
                print("📋 Loading R functions and data...")
            # Load R functions and data
            load_r_functions()
            load_spatial_data()
                _DATA_PRELOADED = True
            elif data_already_loaded:
                print("⚡ Using preloaded data for fast execution")
            
            # Execute the spatial function
            generated_files = execute_spatial_function(config_data, output_dir)
        
        print(f"✅ Successfully generated {len(generated_files)} files")
        return generated_files
        
    except Exception as e:
        print(f"❌ Error in spatial visualization pipeline: {str(e)}")
        raise

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate spatial visualizations from JSON config")
    parser.add_argument("--json_input", required=True, help="Path to JSON configuration file")
    parser.add_argument("--output_dir", default="results", help="Output directory")
    
    args = parser.parse_args()
    
    generated_files = main(args.json_input, args.output_dir)
    
    print("Generated files:")
    for file_info in generated_files:
        print(f"  - {file_info[0]}: {file_info[1]}") 